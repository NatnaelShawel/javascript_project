let price = 30 + 20 ;
showMessage("Addition opertor:"+price); 