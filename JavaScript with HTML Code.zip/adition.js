function showMessage(pricee) {
   
    document.getElementById('pricee').textContent=pricee;
}

