
let welcome='welcome';

showMessage("welcome");
