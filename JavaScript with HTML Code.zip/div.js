let price= 50;
price = price  / 5;
showMessage(price);