function showMessage(price) {
   
    document.getElementById('price').textContent=price;
}

